This code is open source for INSPIRATION.
If you want to remake this project, please do (and send it to me ASAP: before pub. publicly)
